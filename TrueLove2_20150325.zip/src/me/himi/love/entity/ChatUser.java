package me.himi.love.entity;

/**
 * @ClassName:ChatUser
 * @author sparklee liduanwei_911@163.com
 * @date Dec 16, 2014 12:37:15 AM
 */
public class ChatUser implements java.io.Serializable {
    private int userId;

}
