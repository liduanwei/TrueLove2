/** Automatically generated file. DO NOT MODIFY */
package me.himi.love;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}